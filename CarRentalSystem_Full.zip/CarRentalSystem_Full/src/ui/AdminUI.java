package ui;

import model.Car;
import service.CarRentalService;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class AdminUI extends JFrame {

    private CarRentalService service = new CarRentalService();

    public AdminUI() {
        setTitle("Car Rental - Admin");
        setSize(900, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();

        JPanel addCarPanel = new JPanel(new GridLayout(6,2,6,6));
        JTextField idField = new JTextField();
        JTextField brandField = new JTextField();
        JTextField modelField = new JTextField();
        JTextField priceField = new JTextField();
        JTextField imagePathField = new JTextField();
        JButton browseBtn = new JButton("Browse...");
        JButton addButton = new JButton("Add Car");

        addCarPanel.add(new JLabel("Car ID:")); addCarPanel.add(idField);
        addCarPanel.add(new JLabel("Brand:")); addCarPanel.add(brandField);
        addCarPanel.add(new JLabel("Model:")); addCarPanel.add(modelField);
        addCarPanel.add(new JLabel("Price per day:")); addCarPanel.add(priceField);
        addCarPanel.add(new JLabel("Image path (resources/images/...):"));
        JPanel imgRow = new JPanel(new BorderLayout()); imgRow.add(imagePathField, BorderLayout.CENTER); imgRow.add(browseBtn, BorderLayout.EAST);
        addCarPanel.add(imgRow);
        addCarPanel.add(new JLabel("")); addCarPanel.add(addButton);

        browseBtn.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
            int ret = chooser.showOpenDialog(this);
            if (ret == JFileChooser.APPROVE_OPTION) {
                File f = chooser.getSelectedFile();
                imagePathField.setText("resources/images/" + f.getName());
                JOptionPane.showMessageDialog(this, "Copy file into project resources/images/ and keep path: resources/images/" + f.getName());
            }
        });

        addButton.addActionListener(e -> {
            try {
                Car car = new Car(
                        idField.getText().trim(),
                        brandField.getText().trim(),
                        modelField.getText().trim(),
                        Double.parseDouble(priceField.getText().trim()),
                        imagePathField.getText().trim()
                );
                service.addCar(car);
                JOptionPane.showMessageDialog(this, "Car added!");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        JPanel viewPanel = new JPanel(new BorderLayout());
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> carList = new JList<>(listModel);
        JTextArea details = new JTextArea();
        details.setEditable(false);
        JLabel imageLabel = new JLabel();
        JPanel right = new JPanel(new BorderLayout());
        right.add(new JScrollPane(details), BorderLayout.CENTER);
        right.add(imageLabel, BorderLayout.SOUTH);

        JButton loadBtn = new JButton("Load Cars");
        JButton makeAvailableBtn = new JButton("Make Available");

        JPanel topRow = new JPanel(); topRow.add(loadBtn); topRow.add(makeAvailableBtn);
        viewPanel.add(topRow, BorderLayout.NORTH);
        viewPanel.add(new JScrollPane(carList), BorderLayout.WEST);
        viewPanel.add(right, BorderLayout.CENTER);

        loadBtn.addActionListener(e -> {
            listModel.clear();
            for (Car c : service.getCars()) {
                listModel.addElement(c.getId() + " | " + c.getBrand() + " " + c.getModel());
            }
        });

        carList.addListSelectionListener(e -> {
            if (carList.getSelectedIndex() == -1) return;
            String sel = listModel.get(carList.getSelectedIndex());
            String id = sel.split("\\|")[0].trim();
            for (Car c : service.getCars()) {
                if (c.getId().equals(id)) {
                    details.setText(c.toString());
                    if (c.getImagePath() != null && !c.getImagePath().isEmpty()) {
                        ImageIcon ico = new ImageIcon(c.getImagePath());
                        Image scaled = ico.getImage().getScaledInstance(420,230,Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaled));
                    } else {
                        imageLabel.setIcon(null);
                    }
                }
            }
        });

        makeAvailableBtn.addActionListener(e -> {
            if (carList.getSelectedIndex() == -1) return;
            String sel = listModel.get(carList.getSelectedIndex());
            String id = sel.split("\\|")[0].trim();
            String msg = service.returnCar(id);
            JOptionPane.showMessageDialog(this, msg);
            loadBtn.doClick();
        });

        tabs.add("Add Car", addCarPanel);
        tabs.add("Manage Cars", viewPanel);

        add(tabs);
    }
}
