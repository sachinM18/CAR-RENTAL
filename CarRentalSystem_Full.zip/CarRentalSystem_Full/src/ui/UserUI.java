package ui;

import model.Car;
import service.CarRentalService;

import javax.swing.*;
import java.awt.*;

public class UserUI extends JFrame {

    private CarRentalService service = new CarRentalService();

    public UserUI() {
        setTitle("Car Rental - User");
        setSize(900, 560);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new BorderLayout());
        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> carList = new JList<>(listModel);
        JTextArea details = new JTextArea();
        details.setEditable(false);
        JLabel imageLabel = new JLabel();
        JPanel right = new JPanel(new BorderLayout());
        right.add(new JScrollPane(details), BorderLayout.CENTER);
        right.add(imageLabel, BorderLayout.SOUTH);

        JButton loadBtn = new JButton("Load Cars");
        JButton rentBtn = new JButton("Rent Selected");

        JPanel topRow = new JPanel(); topRow.add(loadBtn); topRow.add(rentBtn);

        p.add(topRow, BorderLayout.NORTH);
        p.add(new JScrollPane(carList), BorderLayout.WEST);
        p.add(right, BorderLayout.CENTER);

        loadBtn.addActionListener(e -> {
            listModel.clear();
            for (Car c : service.getCars()) {
                listModel.addElement(c.getId() + " | " + c.getBrand() + " " + c.getModel() + " | " + (c.isAvailable() ? "Available" : "Rented"));
            }
        });

        carList.addListSelectionListener(e -> {
            if (carList.getSelectedIndex() == -1) return;
            String sel = listModel.get(carList.getSelectedIndex());
            String id = sel.split("\\|")[0].trim();
            for (Car c : service.getCars()) {
                if (c.getId().equals(id)) {
                    details.setText(c.toString());
                    if (c.getImagePath() != null && !c.getImagePath().isEmpty()) {
                        ImageIcon ico = new ImageIcon(c.getImagePath());
                        Image scaled = ico.getImage().getScaledInstance(420,230,Image.SCALE_SMOOTH);
                        imageLabel.setIcon(new ImageIcon(scaled));
                    } else {
                        imageLabel.setIcon(null);
                    }
                }
            }
        });

        rentBtn.addActionListener(e -> {
            if (carList.getSelectedIndex() == -1) { JOptionPane.showMessageDialog(this, "Select a car"); return; }
            String sel = listModel.get(carList.getSelectedIndex());
            String id = sel.split("\\|")[0].trim();
            String name = JOptionPane.showInputDialog(this, "Your name?");
            String mobile = JOptionPane.showInputDialog(this, "Mobile?");
            if (name == null || mobile == null) return;
            String msg = service.rentCar(id, name, mobile);
            JOptionPane.showMessageDialog(this, msg);
            loadBtn.doClick();
        });

        add(p);
    }
}
