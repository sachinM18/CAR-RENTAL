package ui;

import model.User;
import service.AuthService;

import javax.swing.*;
import java.awt.*;

public class LoginUI extends JFrame {

    private AuthService authService = new AuthService();

    public LoginUI() {
        setTitle("Car Rental - Login");
        setSize(360, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel p = new JPanel(new GridLayout(3,2,6,6));
        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JButton loginBtn = new JButton("Login");

        p.add(new JLabel("Username:")); p.add(userField);
        p.add(new JLabel("Password:")); p.add(passField);
        p.add(new JLabel()); p.add(loginBtn);

        add(p);

        loginBtn.addActionListener(e -> {
            String u = userField.getText().trim();
            String pw = new String(passField.getPassword());
            User user = authService.authenticate(u, pw);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Invalid credentials");
                return;
            }
            JOptionPane.showMessageDialog(this, "Welcome " + user.getUsername() + " (" + user.getRole() + ")");
            dispose();
            if ("ADMIN".equals(user.getRole())) {
                new AdminUI().setVisible(true);
            } else {
                new UserUI().setVisible(true);
            }
        });
    }
}
