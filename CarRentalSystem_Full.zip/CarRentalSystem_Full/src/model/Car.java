package model;

import java.io.Serializable;

public class Car implements Serializable {
    private String id;
    private String brand;
    private String model;
    private double pricePerDay;
    private boolean available;
    private String imagePath;

    public Car(String id, String brand, String model, double pricePerDay, String imagePath) {
        this.id = id;
        this.brand = brand;
        this.model = model;
        this.pricePerDay = pricePerDay;
        this.available = true;
        this.imagePath = imagePath;
    }

    public String getId() { return id; }
    public String getBrand() { return brand; }
    public String getModel() { return model; }
    public double getPricePerDay() { return pricePerDay; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
    public String getImagePath() { return imagePath; }

    @Override
    public String toString() {
        return id + " - " + brand + " " + model + " | ₹" + pricePerDay + "/day | " +
               (available ? "Available" : "Rented");
    }
}
