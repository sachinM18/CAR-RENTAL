package model;

import java.io.Serializable;
import java.time.LocalDate;

public class Rental implements Serializable {
    private Car car;
    private Customer customer;
    private LocalDate rentDate;

    public Rental(Car car, Customer customer) {
        this.car = car;
        this.customer = customer;
        this.rentDate = LocalDate.now();
    }

    public Car getCar() { return car; }
    public Customer getCustomer() { return customer; }
    public LocalDate getRentDate() { return rentDate; }

    @Override
    public String toString() {
        return car.getBrand() + " " + car.getModel() +
               " rented by " + customer.getName() +
               " on " + rentDate;
    }
}
