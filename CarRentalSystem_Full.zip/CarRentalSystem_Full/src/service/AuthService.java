package service;

import model.User;

import java.io.*;
import java.util.ArrayList;

public class AuthService {

    private ArrayList<User> users = new ArrayList<>();
    private final String USER_FILE = "users.dat";

    public AuthService() {
        loadUsers();
    }

    public void addUser(User u) {
        users.add(u);
        saveUsers();
    }

    public User authenticate(String username, String password) {
        for (User u : users) {
            if (u.getUsername().equals(username) && u.getPassword().equals(password)) {
                return u;
            }
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private void loadUsers() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(USER_FILE))) {
            users = (ArrayList<User>) in.readObject();
        } catch (Exception e) {
            users.add(new User("admin", "admin", "ADMIN"));
            users.add(new User("user", "user", "USER"));
            saveUsers();
        }
    }

    private void saveUsers() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(USER_FILE))) {
            out.writeObject(users);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
