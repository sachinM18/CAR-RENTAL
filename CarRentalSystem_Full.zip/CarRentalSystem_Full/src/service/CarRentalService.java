package service;

import model.Car;
import model.Customer;
import model.Rental;

import java.io.*;
import java.util.ArrayList;

public class CarRentalService {

    private ArrayList<Car> cars = new ArrayList<>();
    private ArrayList<Rental> rentals = new ArrayList<>();

    private final String CAR_FILE = "cars.dat";
    private final String RENTAL_FILE = "rentals.dat";

    public CarRentalService() {
        loadData();
    }

    public void addCar(Car car) {
        cars.add(car);
        saveData();
    }

    public ArrayList<Car> getCars() {
        return cars;
    }

    public ArrayList<Rental> getRentals() {
        return rentals;
    }

    public String rentCar(String carId, String customerName, String mobile) {
        for (Car car : cars) {
            if (car.getId().equals(carId) && car.isAvailable()) {
                Customer customer = new Customer(customerName, mobile);
                Rental rental = new Rental(car, customer);
                rentals.add(rental);
                car.setAvailable(false);
                saveData();
                return "Car rented successfully!";
            }
        }
        return "Car not available!";
    }

    public String returnCar(String carId) {
        for (Car car : cars) {
            if (car.getId().equals(carId)) {
                car.setAvailable(true);
                saveData();
                return "Car returned successfully!";
            }
        }
        return "Car not found!";
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        try (ObjectInputStream carIn = new ObjectInputStream(new FileInputStream(CAR_FILE))) {
            cars = (ArrayList<Car>) carIn.readObject();
        } catch (Exception ignored) {}

        try (ObjectInputStream rentIn = new ObjectInputStream(new FileInputStream(RENTAL_FILE))) {
            rentals = (ArrayList<Rental>) rentIn.readObject();
        } catch (Exception ignored) {}
    }

    private void saveData() {
        try (ObjectOutputStream carOut = new ObjectOutputStream(new FileOutputStream(CAR_FILE))) {
            carOut.writeObject(cars);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try (ObjectOutputStream rentOut = new ObjectOutputStream(new FileOutputStream(RENTAL_FILE))) {
            rentOut.writeObject(rentals);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
